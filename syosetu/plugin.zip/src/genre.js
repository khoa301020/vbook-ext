function execute() {
    return Response.success([
        {title: "異世界〔恋愛〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_101/", script: "gen.js"},
        {title: "現実世界〔恋愛〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_102/", script: "gen.js"},
        {title: "ハイファンタジー〔ファンタジー〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_201/", script: "gen.js"},
        {title: "ローファンタジー〔ファンタジー〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_202/", script: "gen.js"},
        {title: "純文学〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_301/", script: "gen.js"},
        {title: "ヒューマンドラマ〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_302/", script: "gen.js"},
        {title: "歴史〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_303/", script: "gen.js"},
        {title: "推理〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_304/", script: "gen.js"},
        {title: "ホラー〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_305/", script: "gen.js"},
        {title: "アクション〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_306/", script: "gen.js"},
        {title: "コメディー〔文芸〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_307/", script: "gen.js"},
        {title: "VRゲーム〔SF〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_401/", script: "gen.js"},
        {title: "宇宙〔SF〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_402/", script: "gen.js"},
        {title: "空想科学〔SF〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_403/", script: "gen.js"},
        {title: "パニック〔SF〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_404/", script: "gen.js"},
        {title: "童話〔その他〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_9901/", script: "gen.js"},
        {title: "詩〔その他〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_9902/", script: "gen.js"},
        {title: "エッセイ〔その他〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_9903/", script: "gen.js"},
        {title: "その他〔その他〕", input: "https://yomou.syosetu.com/rank/genrelist/type/monthly_9999/", script: "gen.js"},
    ]);
}